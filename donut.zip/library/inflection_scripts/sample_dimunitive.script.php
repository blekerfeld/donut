<?php

// Donut sample inflection script

// A script has a function name pExecuteScript_{scriptname}! 




function pExecuteScript_name($inflect_this, $original_word){


	return $inflect_this + $original_word;

}





?>