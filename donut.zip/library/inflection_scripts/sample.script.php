<?php

// Donut sample inflection script

// A script has a function




function pExecuteScript_sample($inflect_this, $word, $mode, $submode, $number){


	return $inflect_this;

}





?>