<?php
pOut('<span class="title_header">Error 404</span>', true);
pOut('<div class="notice danger-notice" id="empty"><i class="fa fa-warning"></i> The requested page can\'t be found or doesn\'t exist at all.</div>');

?>