<?php


// We don't have to be here, bye
header("Location: ../index.php");

// This page is as dead as a doornail, just as old Marly.
die();