<?php

// This is just a lazyass redirect

pUrl('index.php?home&search='.$_GET['search'], true);
